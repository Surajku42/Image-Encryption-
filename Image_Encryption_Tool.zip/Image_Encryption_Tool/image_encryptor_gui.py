import cv2
import numpy as np
import random
import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk

class ImageEncryptor:
    def __init__(self, key: int):
        self.key = key
        random.seed(key)

    def _generate_swap_indices(self, shape):
        indices = [(i, j) for i in range(shape[0]) for j in range(shape[1])]
        random.shuffle(indices)
        return indices

    def encrypt(self, img):
        h, w, _ = img.shape
        encrypted_img = cv2.bitwise_xor(img, self.key)

        swap_indices = self._generate_swap_indices((h, w))
        for idx, (i, j) in enumerate(swap_indices):
            i2, j2 = swap_indices[-(idx + 1)]
            encrypted_img[i, j], encrypted_img[i2, j2] = encrypted_img[i2, j2], encrypted_img[i, j]

        return encrypted_img

    def decrypt(self, img):
        h, w, _ = img.shape
        decrypted_img = img.copy()

        swap_indices = self._generate_swap_indices((h, w))

        for idx in reversed(range(len(swap_indices))):
            i, j = swap_indices[idx]
            i2, j2 = swap_indices[-(idx + 1)]
            decrypted_img[i, j], decrypted_img[i2, j2] = decrypted_img[i2, j2], decrypted_img[i, j]

        decrypted_img = cv2.bitwise_xor(decrypted_img, self.key)
        return decrypted_img


class EncryptionApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Image Encryption & Decryption Tool")
        self.image = None
        self.image_path = None

        self.key_label = tk.Label(root, text="Secret Key:")
        self.key_label.pack()
        self.key_entry = tk.Entry(root)
        self.key_entry.pack()

        self.load_button = tk.Button(root, text="Load Image", command=self.load_image)
        self.load_button.pack()

        self.encrypt_button = tk.Button(root, text="Encrypt & Save", command=self.encrypt_image)
        self.encrypt_button.pack()

        self.decrypt_button = tk.Button(root, text="Decrypt & Save", command=self.decrypt_image)
        self.decrypt_button.pack()

        self.img_label = tk.Label(root)
        self.img_label.pack()

    def load_image(self):
        file_path = filedialog.askopenfilename(filetypes=[("Image Files", "*.jpg *.png *.jpeg")])
        if file_path:
            self.image_path = file_path
            self.display_image(file_path)
            self.image = cv2.imread(file_path)
            messagebox.showinfo("Loaded", "Image Loaded Successfully!")

    def display_image(self, path):
        pil_img = Image.open(path).resize((300, 300))
        tk_img = ImageTk.PhotoImage(pil_img)
        self.img_label.config(image=tk_img)
        self.img_label.image = tk_img

    def encrypt_image(self):
        if self.image is None:
            messagebox.showwarning("Error", "Please load an image first!")
            return

        try:
            key = int(self.key_entry.get())
            encryptor = ImageEncryptor(key)
            encrypted_img = encryptor.encrypt(self.image)
            save_path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG files", "*.png")])

            if save_path:
                cv2.imwrite(save_path, encrypted_img)
                messagebox.showinfo("Success", f"Encrypted image saved at:\n{save_path}")
        except ValueError:
            messagebox.showwarning("Error", "Please enter a valid numeric key.")

    def decrypt_image(self):
        if self.image is None:
            messagebox.showwarning("Error", "Please load an image first!")
            return

        try:
            key = int(self.key_entry.get())
            encryptor = ImageEncryptor(key)
            decrypted_img = encryptor.decrypt(self.image)
            save_path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG files", "*.png")])

            if save_path:
                cv2.imwrite(save_path, decrypted_img)
                messagebox.showinfo("Success", f"Decrypted image saved at:\n{save_path}")
        except ValueError:
            messagebox.showwarning("Error", "Please enter a valid numeric key.")


if __name__ == "__main__":
    root = tk.Tk()
    app = EncryptionApp(root)
    root.mainloop()
